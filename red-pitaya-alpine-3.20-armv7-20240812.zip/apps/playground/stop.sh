#! /bin/sh

killall -q playground
